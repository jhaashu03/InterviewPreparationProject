CREATE TRIGGER TR_OrionConfiguration_Row ON OrionConfiguration AFTER INSERT, DELETE AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Count INT = (SELECT COUNT(*) FROM dbo.OrionConfiguration)
    IF @Count <> 1
    BEGIN
        RAISERROR ('OrionConfiguration table must have exactly one row', 16, 1)
        ROLLBACK TRANSACTION
    END
    SET NOCOUNT OFF;
END

-- Drop Old constrain (only user name is unique)
IF EXISTS(SELECT 1 FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[UQ_OrionUsers_Name]') AND type = 'K')
BEGIN
  ALTER TABLE [dbo].[OrionUsersMT]
      DROP CONSTRAINT [UQ_OrionUsers_Name]
END
go


CREATE PROCEDURE SP_Core_ValidateTenancy
  @ProcId int,
  @TenantIds tenant_ids readonly,
  @ExcludeTenantId int = NULL
AS
BEGIN
  -- no-op
  RETURN
END
go


create trigger [dbo].[TR_OrionDashboardPage_UniqueKey] ON [dbo].[OrionDashboardPageMT] for insert, update as
	if exists (
	  select 1 from [dbo].[OrionDashboardPageMT] q
	    inner join inserted i
			on q.UniqueKey = i.UniqueKey -- nulls will drop out; they don't equal anything
		  group by q.UniqueKey
	    having count(*) > 1          -- if there is more than one row with given values, uniqueness has been violated
	)
	begin
		raiserror ('Cannot have duplicate UniqueKey values in OrionDashboardPage', 16, 1)
		rollback transaction
	end
go


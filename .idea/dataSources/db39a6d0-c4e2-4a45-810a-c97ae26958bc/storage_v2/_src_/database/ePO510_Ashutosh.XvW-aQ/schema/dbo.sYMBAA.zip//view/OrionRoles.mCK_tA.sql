CREATE VIEW OrionRoles AS
    SELECT * FROM OrionRolesMT
    WHERE GroupId IN (SELECT Id FROM OrionGroups)
go


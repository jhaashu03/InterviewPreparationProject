CREATE PROCEDURE [dbo].[SP_Core_Upgrade_Drop_FK]
	@TableNameRef	NVARCHAR(128)
AS
BEGIN
	DECLARE
		@StartTimeStamp	DATETIME
	,	@TimeStamp		VARCHAR(100);

	SELECT
		@StartTimeStamp	= GETUTCDATE()
	,	@TimeStamp		= CONVERT(VARCHAR(100), GETDATE());

	IF NOT EXISTS	(SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'OrionFKRecreation') AND type in (N'U'))
	BEGIN
		CREATE TABLE [dbo].[OrionFKRecreation]
		(
			[Name]			[varchar](512)	NULL
		,	[ParentTable]	[varchar](512)	NULL
		,	[ParentColumn]	[varchar](512)	NULL
		,	[PKTable]		[varchar](512)	NULL
		,	[PKColumn]		[varchar](512)	NULL
		,   [DeleteAction]	[TINYINT]
		,	[DeleteType]	[NVARCHAR](60)
		,	[UpdateAction]	[TINYINT]
		,	[UpdateType]	[NVARCHAR](60)
		) ON [PRIMARY]
	END


	-- get fk
	DECLARE
		@StartDateTime	DATETIME
	,	@EndDateTime	DATETIME
	,	@Name			NVARCHAR(512)
	,	@ParentTable	NVARCHAR(512);

	INSERT INTO	OrionFKRecreation
	(
		Name
	,	ParentTable
	,	ParentColumn
	,	PKTable
	,	PKColumn
	,	DeleteAction
	,	DeleteType
	,	UpdateAction
	,	UpdateType
	)
	SELECT
		fk.name								AS Name
	,	OBJECT_NAME(fk.parent_object_id)	AS ParentTable
	,	c1.name								AS Parentcolumn
	,	@TableNameRef
	,	c2.Name
	,	fk.delete_referential_action
	,	fk.delete_referential_action_desc
	,	fk.update_referential_action
	,	fk.update_referential_action_desc
	FROM	sys.foreign_keys		fk
	JOIN	sys.foreign_key_columns	fkc	ON	fkc.constraint_object_id	= fk.object_id
	JOIN	sys.columns				c1	ON	fkc.parent_column_id		= c1.column_id
										AND	fkc.parent_object_id		= c1.object_id
	JOIN	sys.columns				c2	ON	fkc.referenced_column_id	= c2.column_id
										AND	fkc.referenced_object_id	= c2.object_id
	WHERE
		OBJECT_NAME(fk.referenced_object_id)	= @TableNameRef



	SET	@TimeStamp	= CONVERT(VARCHAR(100), GETDATE());
	RAISERROR('<<< DROPPING ALL FK ON TABLE %s : %s >>>', 0, 1, @TableNameRef, @TimeStamp) WITH NOWAIT

	-- Drop all FK
	SELECT
		Name
	,	ParentTable
	,	CAST(0 AS BIT)	AS Processed
	INTO	#TempFKTables
	FROM	OrionFKRecreation
	WHERE
		PKTable	= @TableNameRef

	WHILE EXISTS (SELECT 1 FROM #TempFKTables WHERE Processed = 0)
	BEGIN

		SET	@StartDateTime	= GETUTCDATE();

		SELECT TOP 1
			@Name			= Name
		,	@ParentTable	= ParentTable
		FROM	#TempFKTables
		WHERE
			Processed	= 0

		SET	@TimeStamp	= CONVERT(VARCHAR(100), GETDATE());
		RAISERROR('<<< DROPPING FK %s FROM %s : %s >>>', 0, 1, @Name, @ParentTable, @TimeStamp) WITH NOWAIT


		EXEC	('ALTER TABLE ' + @ParentTable + ' DROP CONSTRAINT ' + @Name)

		UPDATE	#TempFKTables
		SET
			Processed	= 1
		WHERE
			Name		= @Name
		AND	ParentTable	= @ParentTable

		SET @EndDateTime	= GETUTCDATE();



		SET	@TimeStamp	= CONVERT(VARCHAR(100), GETDATE());
		RAISERROR('<<< DROPPED FK %s FROM %s : %s >>>', 0, 1, @Name, @ParentTable, @TimeStamp) WITH NOWAIT

	END

	DROP TABLE	#TempFKTables
END
go


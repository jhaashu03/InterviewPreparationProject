-- Function to work around the fact that DATEDIFF returns an INT instead of
--  something capable of holding more than 24 days worth of milliseconds.
-- This function expects endDate to be after startDate.
CREATE FUNCTION dbo.diffMillisecond
 (@startDate datetime, @endDate datetime)
RETURNS BIGINT
AS
BEGIN
	return (DATEDIFF(second, @startDate, @endDate) * CONVERT(BIGINT, 1000)) +
	ABS(DATEPART(MILLISECOND, @startDate) - DATEPART(MILLISECOND, @endDate))
END
go


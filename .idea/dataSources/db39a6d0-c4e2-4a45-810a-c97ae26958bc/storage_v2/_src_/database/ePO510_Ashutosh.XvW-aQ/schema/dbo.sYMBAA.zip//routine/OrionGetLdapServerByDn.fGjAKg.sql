CREATE PROCEDURE dbo.OrionGetLdapServerByDn
(
    @dn nvarchar(2000)
)
AS
BEGIN
--------------------------------------------------------------------------------
-- Author: Niklas Hï¿½glund
-- Procedure to return the server id from the OrionLdapServers table of the
-- server that has the given DN.
-- @dn The DN to query for.
-- Raises an error if the server can't be found
--------------------------------------------------------------------------------
    SELECT OrionLdapServers.Id
	FROM OrionLdapServers
	INNER JOIN OrionLdapItems ON OrionLdapServers.Id = OrionLdapItems.ServerId
	WHERE OrionLdapItems.Dn = @dn

	-- Raise an error if the server couldn't be found
	IF @@ROWCOUNT <> 1
		RAISERROR ('LDAP server not found', 11, 1)
END
go


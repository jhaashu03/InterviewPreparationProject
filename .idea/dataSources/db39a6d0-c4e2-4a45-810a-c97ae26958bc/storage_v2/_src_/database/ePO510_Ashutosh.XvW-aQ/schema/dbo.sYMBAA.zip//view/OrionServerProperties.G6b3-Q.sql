CREATE  VIEW OrionServerProperties AS SELECT t.* FROM OrionServerPropertiesMT t
go


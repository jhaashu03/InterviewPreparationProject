CREATE TRIGGER [dbo].[TR_OrionQueryGroups_UniqueKey] ON [dbo].[OrionQueryGroupsMT]
FOR INSERT, UPDATE
AS
    IF EXISTS (
        SELECT 1
        FROM [dbo].[OrionQueryGroupsMT] q INNER JOIN inserted i
        ON q.UniqueKey = i.UniqueKey -- nulls will drop out; they don't equal anything
        GROUP BY q.UniqueKey
        HAVING COUNT(*) > 1          -- if there is more than one row with given values, uniqueness has been violated
    )
    BEGIN
        RAISERROR ('Cannot have duplicate UniqueKey values in OrionQueryGroupsMT', 16, 1)
        ROLLBACK TRANSACTION
    END
go


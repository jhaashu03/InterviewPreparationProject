CREATE TRIGGER [dbo].[TR_OrionGroups_UniqueKeyTenantId] ON [dbo].[OrionGroupsMT]
FOR INSERT, UPDATE
AS
	IF EXISTS (
		SELECT 1
		FROM [dbo].[OrionGroupsMT] g INNER JOIN inserted i
		ON g.UniqueKey = i.UniqueKey
		GROUP BY g.UniqueKey, g.TenantId
		HAVING COUNT(*) > 1
	)
	BEGIN
		RAISERROR ('Cannot have duplicate UniqueKey and TenantId values in OrionGroupsMT', 16, 1)
		ROLLBACK TRANSACTION
	END
go


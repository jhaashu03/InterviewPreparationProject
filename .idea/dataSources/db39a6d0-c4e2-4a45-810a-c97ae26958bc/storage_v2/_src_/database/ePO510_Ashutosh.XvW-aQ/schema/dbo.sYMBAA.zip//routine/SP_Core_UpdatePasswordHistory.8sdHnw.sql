CREATE PROCEDURE [dbo].[SP_Core_UpdatePasswordHistory]
	@UserId int,
	@ChangedByUserId int,
	@AuthURI nvarchar(256)
AS
BEGIN
	DECLARE @PasswordHistoryRuleValue int, @AutoId int, @PasswordHistoryCount int;
	SELECT @PasswordHistoryRuleValue = Setting FROM OrionUserAccountRule WHERE Name = 'PasswordHistoryRule' AND Status = 1;
	IF (ISNULL(@PasswordHistoryRuleValue,0) > 0)
	BEGIN
		IF (@UserId = @ChangedByUserId) --Delete Change Password History, if the number of records are more than PasswordHistoryRule value
		BEGIN
			SELECT @PasswordHistoryCount = COUNT(1) FROM OrionUserPasswordHistory WHERE UserId = @UserId AND ChangedByUserId = @UserId;

			SELECT @AutoId = MIN(AutoId) FROM (SELECT TOP (@PasswordHistoryRuleValue) AutoId FROM OrionUserPasswordHistory
										WHERE UserId = @UserId AND ChangedByUserId = @UserId
										ORDER BY AutoId DESC)A

			DELETE FROM  OrionUserPasswordHistory
				WHERE UserId = @UserId  AND ChangedByUserId = @UserId
				AND @PasswordHistoryRuleValue <= @PasswordHistoryCount
				AND AutoId <= @AutoId
		END
		ELSE --Delete Reset Password History, if the number of records are more than PasswordHistoryRule value
		BEGIN
			SELECT @PasswordHistoryCount = COUNT(1) FROM OrionUserPasswordHistory WHERE UserId = @UserId AND ChangedByUserId <> @UserId;

			SELECT @AutoId = MIN(AutoId) FROM (SELECT TOP (@PasswordHistoryRuleValue) AutoId FROM OrionUserPasswordHistory
										WHERE UserId = @UserId AND ChangedByUserId <> @UserId
										ORDER BY AutoId DESC)A
			DELETE FROM  OrionUserPasswordHistory
				WHERE UserId = @UserId  AND ChangedByUserId <> @UserId
				AND @PasswordHistoryRuleValue <= @PasswordHistoryCount
				AND AutoId <= @AutoId
		END
		INSERT INTO OrionUserPasswordHistory(UserId,AuthURI,ChangedByUserId,ChangedOnDate)
		VALUES(@UserId,@AuthURI,@ChangedByUserId,GETDATE());
	END
	RETURN 1;
END
go


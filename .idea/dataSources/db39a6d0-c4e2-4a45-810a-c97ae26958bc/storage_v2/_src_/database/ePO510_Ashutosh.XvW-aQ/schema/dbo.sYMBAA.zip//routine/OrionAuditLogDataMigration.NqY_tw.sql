CREATE PROC dbo.OrionAuditLogDataMigration
(
	@BatchCount int
)
AS
BEGIN
SET NOCOUNT ON;
SET XACT_ABORT ON;

	DECLARE @Start_Id bigint, @End_Id bigint, @RefId bigint, @InsertRow bigint, @DeleteRow bigint, @LogID int;

	SELECT @Start_Id = MAX(AutoID), @RefId = MIN(AutoID) FROM dbo.OrionAuditLogMTDrop WITH (NOLOCK);
	SET @End_Id = CASE WHEN @Start_Id - @BatchCount < 0 THEN 0 ELSE @Start_Id - @BatchCount END;

	BEGIN TRY
		IF @RefId > 0
		BEGIN

      -- EPOMigrationLog will be available only after ePO installation and used by ePO server task
			INSERT dbo.EPOMigrationLog (Event,StartID,EndID,StartTime)
			VALUES('OrionAuditLog', @Start_Id, @End_Id, GETUTCDATE());

			SET @LogID = SCOPE_IDENTITY();

			SET IDENTITY_INSERT dbo.OrionAuditLog ON;

			INSERT dbo.OrionAuditLog
			(
				AutoId,
				UserId,
				UserName,
				Priority,
				CmdName,
				Message,
				Success,
				StartTime,
				EndTime,
				RemoteAddress,
				LocalAddress,
				TenantId
			)

			SELECT
				AutoId,
				UserId,
				UserName,
				Priority,
				CmdName,
				Message,
				Success,
				StartTime,
				EndTime,
				RemoteAddress,
				LocalAddress,
				TenantId
			FROM dbo.OrionAuditLogMTDrop WITH (NOLOCK)
			WHERE AutoID <= @Start_Id AND AutoID > @End_Id;

			SET @InsertRow = @@ROWCOUNT;

			SET IDENTITY_INSERT dbo.OrionAuditLog OFF;

			IF @InsertRow > 0
			BEGIN
				DELETE dbo.OrionAuditLogMTDrop
				WHERE AutoID <= @Start_Id AND AutoID > @End_Id;

				SET @DeleteRow = @@ROWCOUNT;
			END

			UPDATE dbo.EPOMigrationLog SET InsertRowCnt = @InsertRow, DeleteRowCnt = @DeleteRow, EndTime = GETUTCDATE(), Status = 'S'
			WHERE LogID = @LogID;

			IF NOT EXISTS(SELECT TOP 1 1 FROM dbo.OrionAuditLogMTDrop)
				DROP TABLE dbo.OrionAuditLogMTDrop;

		END
		ELSE
		BEGIN
			IF NOT EXISTS(SELECT TOP 1 1 FROM dbo.OrionAuditLogMTDrop)
			DROP TABLE dbo.OrionAuditLogMTDrop;
		END
	END TRY
	BEGIN CATCH
		DECLARE
			@ErrorMessage NVARCHAR(4000)
		,	@ErrorSeverity INT
		,	@ErrorState INT;

		SELECT
			@ErrorMessage = ERROR_MESSAGE(),
			@ErrorSeverity = ERROR_SEVERITY(),
			@ErrorState = ERROR_STATE();


		UPDATE dbo.EPOMigrationLog SET InsertRowCnt = @InsertRow, DeleteRowCnt = @DeleteRow, EndTime = GETUTCDATE(), Status = 'F', ErrorMsg = ERROR_MESSAGE()
		WHERE LogID = @LogID;

		-- Use RAISERROR inside the CATCH block to return error
		-- information about the original error that caused
		-- execution to jump to the CATCH block.
		RAISERROR (@ErrorMessage, -- Message text.
				   @ErrorSeverity, -- Severity.
				   @ErrorState -- State.
				   );
	END CATCH

END
go


CREATE PROCEDURE dbo.SP_LdapSync_GetParentDn
(
    @ChildId int
)
AS
BEGIN
--------------------------------------------------------------------------------
-- Find all direct parent and registered parent Guids and Dns for a given child
-- item id.
--
-- @ChildId is the item to do the search for.
--
-- Note that in the configuration group1 -> group2 -> group3 -> user1 where "->"
-- denotes parental ownership and group1 is registered.  SP_LdapSync_GetParentDn
-- will return data for group1 and group3 only when queried for user1.
-- For a full discussion of this issue please refer to BZ841226.
--------------------------------------------------------------------------------
	-- Select the direct parents.
	SELECT T1.UniqueId, T1.Dn
	FROM OrionLdapItems AS T1
		INNER JOIN OrionLdapChildren AS T2
			ON T1.Id = T2.ParentId AND T2.ChildId IN (select Id from OrionLdapItems
      where UniqueId IN (select UniqueId FROM OrionLdapItems where Id = @ChildId))

	UNION
	-- Select any registered transitive parents.
	SELECT T1.UniqueId, T1.Dn
	FROM OrionLdapItems AS T1
		INNER JOIN OrionLdapChildren AS T2
			ON T1.Id = T2.ParentId
		INNER JOIN OrionLdapChildren AS T3
			ON T2.ChildId = T3.ParentId AND T3.ChildId = @ChildId
END
go


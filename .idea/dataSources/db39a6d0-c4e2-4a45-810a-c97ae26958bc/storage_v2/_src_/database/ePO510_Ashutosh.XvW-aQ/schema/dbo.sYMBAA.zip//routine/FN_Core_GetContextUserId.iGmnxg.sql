CREATE FUNCTION FN_Core_GetContextUserId()
  RETURNS int
  BEGIN
    RETURN dbo.FN_Core_GetContextUserIdImpl()
  END
go


CREATE procedure [dbo].[SP_Task_DeleteTaskLogEntry]
(
	@ID bigint,
	@TenantId int = null
)
AS
begin
    set NOCOUNT on;
	begin transaction;

    -- first delete child entries
	declare @ChildId bigint;
	declare @cur cursor

  IF @TenantId is null
    SET @TenantId = dbo.FN_Core_GetContextTenantId();


	if( @TenantId > 1 )
	    set @cur = cursor for select Id from OrionSchedulerTaskLog where ParentId = @ID and TenantId = @TenantId;
	else
	    set @cur = cursor for select Id from OrionSchedulerTaskLog where ParentId = @ID
	open @cur
    fetch next from @cur into @ChildId;
    while @@FETCH_STATUS = 0
        begin
           exec SP_Task_DeleteTaskLogEntry @ChildId, @TenantId;
           fetch next from @cur into @ChildId;
        end
	close @cur;
	deallocate @cur;

    -- then delete entry
    if( @TenantId > 1 )
        delete from OrionSchedulerTaskLog where Id = @ID and TenantId = @TenantId;
    else
        delete from OrionSchedulerTaskLog where Id = @ID
	commit transaction;
end
go


CREATE VIEW OrionGroupMemberships AS
    SELECT * FROM OrionGroupMembershipsMT
    WHERE OrionGroupMembershipsMT.GroupId IN (SELECT Id FROM OrionGroups)
go


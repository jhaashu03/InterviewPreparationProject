CREATE FUNCTION [dbo].[OrionLdapSqlVersion] ()
RETURNS int
AS
BEGIN
  DECLARE @productVersion varchar(200);
  DECLARE @pos int
  DECLARE @sqlVersion int
  SET @sqlVersion = 0
  SET @productVersion = cast(ServerProperty('productversion') as varchar(200))
  SET @pos = charindex('.', @productVersion)
  IF @pos != 0 BEGIN
    SET @sqlVersion = cast(substring(@productVersion, 0, @pos) as int)
  END
  RETURN @sqlVersion
END
go


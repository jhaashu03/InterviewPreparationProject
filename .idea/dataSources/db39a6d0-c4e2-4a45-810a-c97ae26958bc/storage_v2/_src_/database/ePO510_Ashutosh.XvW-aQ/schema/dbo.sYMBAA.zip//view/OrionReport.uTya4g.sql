CREATE VIEW OrionReport AS
    SELECT * FROM OrionReportMT
    WHERE OrionReportMT.GroupId IN (SELECT Id FROM OrionQueryGroups)
go


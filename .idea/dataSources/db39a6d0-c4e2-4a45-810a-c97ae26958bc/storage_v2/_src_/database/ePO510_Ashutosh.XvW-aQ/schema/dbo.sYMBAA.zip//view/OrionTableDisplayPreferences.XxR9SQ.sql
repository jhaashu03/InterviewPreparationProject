CREATE VIEW OrionTableDisplayPreferences AS (SELECT * FROM OrionTableDisplayPreferencesMT)
go


CREATE FUNCTION FN_Core_UNKNOWN_ID()
RETURNS int
BEGIN
  -- Must be kept in sync with MfsDatabase.UNKNOWN_ID
  RETURN 0x80000000
END
go


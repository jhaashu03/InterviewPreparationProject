CREATE  VIEW OrionRegisteredServers AS SELECT t.* FROM OrionRegisteredServersMT t
go


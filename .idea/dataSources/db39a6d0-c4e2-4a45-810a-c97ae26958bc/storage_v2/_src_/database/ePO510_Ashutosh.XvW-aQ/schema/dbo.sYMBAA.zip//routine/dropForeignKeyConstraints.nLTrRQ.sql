CREATE PROCEDURE dropForeignKeyConstraints(
	@tableName NVARCHAR(512)
)
AS
BEGIN
	DECLARE
	@constraintName VARCHAR(512),
	@columnName VARCHAR(512),
	@fkParentTableName VARCHAR(512),
	@deleteAction VARCHAR(512),
	@referenceColumnName VARCHAR(512),
	@updateAction VARCHAR(512);

	SELECT OBJECT_NAME(f.parent_object_id) TableName,COL_NAME(fc.parent_object_id,fc.parent_column_id) ColName,COL_NAME(fc.referenced_object_id,fc.referenced_column_id) RefColName,f.name ForeignKeyName, f.delete_referential_action_desc DeleteAction, f.update_referential_action_desc UpdateAction,CAST(0 AS BIT ) AS FKProcessed
	  INTO #tempFKTable
		FROM sys.foreign_keys AS f
		INNER JOIN sys.foreign_key_columns AS fc ON f.OBJECT_ID = fc.constraint_object_id
		INNER JOIN sys.tables t ON t.OBJECT_ID = fc.referenced_object_id
		WHERE OBJECT_NAME (f.referenced_object_id) = @tableName;

	SELECT TOP 1 @constraintName = ForeignKeyName,
				 @columnName = ColName,
				 @fkParentTableName = TableName,
				 @deleteAction = DeleteAction,
				 @referenceColumnName = RefColName,
				 @updateAction = UpdateAction FROM #tempFKTable WHERE FKProcessed=0;

	WHILE EXISTS (SELECT 1 FROM #tempFKTable where FKProcessed=0)
	BEGIN
		EXEC('ALTER TABLE '+@fkParentTableName+' DROP CONSTRAINT ['+@constraintName+']');

		INSERT INTO _bigint_migration_590 (TableName,ColumnName,ReferencedColumnName,CName,FKParentTable,Processed,OnlyFKDropped,DelAction,UpdAction)
		VALUES(@fkParentTableName,@columnName,@referenceColumnName,@constraintName,@tableName,0,1,@deleteAction, @updateAction)

		UPDATE #tempFKTable set FKProcessed=1 WHERE ForeignKeyName = @constraintName;

		SELECT TOP 1 @constraintName = ForeignKeyName,
				 @columnName = ColName,
				 @fkParentTableName = TableName,
				 @deleteAction = DeleteAction,
				 @referenceColumnName = RefColName,
				 @updateAction = UpdateAction FROM #tempFKTable WHERE FKProcessed=0;
	END
END;
go


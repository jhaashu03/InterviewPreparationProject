CREATE PROCEDURE SP_LdapSync_GetUnreferencedItems
(
	@leafNode bit
)
AS
BEGIN
    ----------------------------------------------------------------------------
    -- Return a set containing only unreferenced OrionLdapItems.  An item is
    -- unreferenced if it is not explicitly owned by an OrionLdapRequiredItem
    -- or implicitly owned as a child of another OrionLdapItem.
    --
    -- @author Wayne Gibson, Jonathan Oulds
    --------------------------------------------------------------------------------
    SELECT * FROM OrionLdapItems
        WHERE [LeafNode] = @leafNode AND
            ID NOT IN
            (
                SELECT [ItemId] FROM [OrionLdapRequiredItems]
                UNION
                SELECT [ChildId] FROM [OrionLdapChildItems]
                UNION
                SELECT [ChildId] FROM [OrionLdapChildGroups]
            )
        ORDER BY ID
END
go


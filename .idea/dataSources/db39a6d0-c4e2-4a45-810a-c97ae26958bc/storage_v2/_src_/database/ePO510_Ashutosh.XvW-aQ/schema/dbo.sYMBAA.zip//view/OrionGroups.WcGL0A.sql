CREATE  VIEW OrionGroups AS SELECT t.* FROM OrionGroupsMT t
go


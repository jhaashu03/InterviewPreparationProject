CREATE  VIEW OrionExportPreferences AS SELECT t.* FROM OrionExportPreferencesMT t
go


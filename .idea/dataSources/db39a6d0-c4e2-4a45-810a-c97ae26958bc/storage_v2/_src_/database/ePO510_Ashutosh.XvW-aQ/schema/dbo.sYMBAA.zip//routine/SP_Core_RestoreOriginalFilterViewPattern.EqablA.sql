CREATE PROCEDURE [dbo].[SP_Core_RestoreOriginalFilterViewPattern]
    @ViewName nvarchar(256)
AS

  BEGIN
    DECLARE
       @Query		NVARCHAR(MAX)
    ,  @DeleteQuery NVARCHAR(MAX)
    ,	@RealName	NVARCHAR(256)

    RAISERROR('<<< Creating tenant-view for %s.', 0, 1, @ViewName) WITH NOWAIT

    SET @RealName = @ViewName + N'MT'

-- If view exists drop the view
    IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'' + @ViewName + ''))
     BEGIN
        SET @DeleteQuery = 'DROP VIEW '+ @Viewname
        EXEC sp_executesql @DeleteQuery
      END

     SET @Query = 'CREATE VIEW ' + @ViewName + ' AS ' +
                 '
                SELECT * FROM '+@RealName+
           '  WHERE TenantId IN
     (SELECT TenantId FROM dbo.FN_Core_GetContextTenancyInfo())
     OR EXISTS
        (SELECT IsSystemUser FROM dbo.FN_Core_GetContextTenancyInfo() WHERE IsSystemUser = 1)'

    RAISERROR('<<< View script for %s: %s.', 0, 1, @ViewName, @Query) WITH NOWAIT

    EXEC sp_executesql @Query
  END
go


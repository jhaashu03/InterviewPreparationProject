CREATE FUNCTION [dbo].[OrionLdapSplit](
  @delimiter nvarchar(5),
  @list nvarchar(4000)
)
RETURNS @result TABLE
(
  [value] nvarchar(100)
)
AS
BEGIN
    DECLARE @lenString INT

    WHILE len( @list ) > 0
       BEGIN
          SELECT @lenString =
             (CASE charindex( @delimiter, @list )
                 WHEN 0 THEN len( @list )
                 ELSE ( charindex( @delimiter, @list ) -1 )
              END
             )

          INSERT INTO @result
             SELECT substring( @list, 1, @lenString )

          SELECT @list =
             (CASE ( len( @list ) - @lenString )
                 WHEN 0 THEN
                  ''
                 ELSE
                  right( @list, len( @list ) - @lenString - 1 )
              END
             )
       END

    RETURN
END
go


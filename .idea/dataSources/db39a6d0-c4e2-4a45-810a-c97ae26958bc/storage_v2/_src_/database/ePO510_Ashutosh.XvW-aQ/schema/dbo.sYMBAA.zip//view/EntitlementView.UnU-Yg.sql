CREATE VIEW [dbo].[EntitlementView] AS
SELECT
  ('uid'+CONVERT(nvarchar, u.Id)+'-gid'+CONVERT(nvarchar, ISNULL(g.Id, '0'))+'-rid'+CONVERT(nvarchar, ISNULL(r.Id, '0'))) AS Id,
  u.Name AS principalName,
  (CASE WHEN u.AuthURI LIKE 'auth:ntlm?%' THEN '%%ADUSER%%' ELSE '%%EPOUSER%%' END) AS principalType,
  (CASE WHEN u.Admin = 1 THEN '%%ADMIN%%' ELSE ISNULL( g.Name, CASE WHEN u.AuthURI LIKE 'auth:ntlm?%' THEN '%%NOEPOGROUPS%%' ELSE NULL END) END) AS groupName,
  (CASE WHEN u.Admin = 1 THEN '%%ADMIN%%' ELSE ISNULL( CONVERT(nvarchar, g.Id)+'_'+CONVERT(nvarchar(4000), r.RoleURI), CASE WHEN u.AuthURI LIKE 'auth:ntlm?%' THEN '%%NOEPOROLES%%' ELSE NULL END) END) AS roleURI
FROM
  [dbo].[OrionUsers] u
  LEFT JOIN [dbo].[OrionGroupMemberships] m ON m.UserId = u.Id
  LEFT JOIN [dbo].[OrionGroups] g ON g.Id = m.GroupId
  LEFT JOIN [dbo].[OrionRoles] r ON g.Id = r.GroupId
WHERE
  u.Visible = 1
UNION ALL
SELECT
  ('adid'+CONVERT(nvarchar, a.Id)+'-gid'+CONVERT(nvarchar, ISNULL(g.Id, '0'))+'-rid'+CONVERT(nvarchar, ISNULL(r.Id, '0'))) AS Id,
  a.AdGroupDn AS principalName,
  '%%ADGROUP%%' AS principalType,
  g.name AS groupName,
  ISNULL(CONVERT(nvarchar, a.groupId)+'_'+CONVERT(nvarchar(4000), r.RoleURI),'%%NOEPOROLES%%') AS roleURI
FROM
  [dbo].[OrionGroupToAdGroup] a
  LEFT OUTER JOIN [dbo].[OrionGroups] g ON g.Id = a.GroupId
  LEFT OUTER JOIN [dbo].[OrionRoles] r ON g.Id = r.GroupId
UNION ALL
SELECT
  ('gid'+CONVERT(nvarchar, ISNULL(g.Id, '0'))+'-rid'+CONVERT(nvarchar, ISNULL(r.Id, '0'))) AS Id,
  NULL AS principalName,
  '%%EMPTYGROUP%%' AS principalType,
  g.Name AS groupName,
  ISNULL(CONVERT(nvarchar, g.Id)+'_'+CONVERT(nvarchar(4000), r.RoleURI), NULL) AS roleURI
FROM
  [dbo].[OrionGroups] g
  LEFT OUTER JOIN [dbo].[OrionRoles] r ON g.Id = r.GroupId
WHERE
  g.Id NOT IN
    ( SELECT GroupId FROM [dbo].[OrionGroupMemberships] m WHERE m.GroupId = g.Id )
  AND
  g.Id NOT IN
    ( SELECT GroupId FROM [dbo].[OrionGroupToAdGroup] a WHERE a.GroupId = g.Id )
go


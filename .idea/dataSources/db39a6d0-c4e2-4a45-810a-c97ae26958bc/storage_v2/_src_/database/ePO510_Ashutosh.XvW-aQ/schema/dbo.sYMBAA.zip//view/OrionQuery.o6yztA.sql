CREATE VIEW OrionQuery AS
    SELECT * FROM OrionQueryMT
    WHERE OrionQueryMT.GroupId IN (SELECT Id FROM OrionQueryGroups)
go


CREATE VIEW OrionTableFilters AS
    SELECT * FROM OrionTableFiltersMT
    WHERE OrionTableFiltersMT.UserId IN (SELECT Id FROM OrionUsers)
go


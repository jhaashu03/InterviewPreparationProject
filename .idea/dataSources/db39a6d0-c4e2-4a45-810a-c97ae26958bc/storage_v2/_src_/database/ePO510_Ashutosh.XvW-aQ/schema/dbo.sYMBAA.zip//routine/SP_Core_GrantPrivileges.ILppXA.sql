CREATE PROCEDURE SP_Core_GrantPrivileges
  @Select bit,
  @Insert bit,
  @Update bit,
  @Delete bit,
  @References bit,
  @Execute bit,
  @Type char,
  @Object varchar(255),
  @Role varchar(255)
AS
BEGIN
  DECLARE @RevokePrivileges varchar(75) =
  CASE
    WHEN @Type = 'T' OR @Type = 'V' THEN N'SELECT, INSERT, UPDATE, DELETE, REFERENCES'
    WHEN @Type = 'F' THEN N'REFERENCES, EXECUTE'
    WHEN @Type = 'P' THEN N'EXECUTE'
  ELSE ''
  END
  IF LEN(@RevokePrivileges) = 0
    BEGIN
      RAISERROR(N'Invalid type "%s"', 11, 1, @Type)
      RETURN
    END
  DECLARE @Stmt varchar(1024) = N'REVOKE ' + @RevokePrivileges + ' ON object::' + @Object + N' FROM ' + @Role
  RAISERROR(N'Executing: %s', 10, 1, @Stmt) WITH NOWAIT -- prints from procedure
  EXEC (@Stmt)

  DECLARE @Permissions varchar(255) = ''
  IF @Select = 1
    SET @Permissions = @Permissions + N'SELECT, '
  IF @Insert = 1
    SET @Permissions = @Permissions + N'INSERT, '
  IF @Update = 1
    SET @Permissions = @Permissions + N'UPDATE, '
  IF @Delete = 1
    SET @Permissions = @Permissions + N'DELETE, '
  IF @References = 1
    SET @Permissions = @Permissions + N'REFERENCES, '
  IF @Execute = 1
    SET @Permissions = @Permissions + N'EXECUTE, '

  IF LEN(@Permissions) = 0
    RETURN
  ELSE
    BEGIN
      SET @Permissions = LEFT(@Permissions, LEN(@Permissions) - 1)
      SET @Stmt = N'GRANT ' + @Permissions + N' ON object::' + @Object + N' TO ' + @Role
      RAISERROR(N'Executing: %s', 10, 1, @Stmt) WITH NOWAIT
      EXEC (@Stmt)
    END
END
go


CREATE VIEW OrionPersonalPreferences AS
    SELECT * FROM OrionPersonalPreferencesMT
    WHERE OrionPersonalPreferencesMT.UserId IN (SELECT Id FROM OrionUsers)
go


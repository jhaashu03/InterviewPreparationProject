CREATE PROCEDURE SP_Core_MoveSP
(
  @name VARCHAR(255),
  @newName VARCHAR(255)
)
AS
BEGIN
  IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[' + @name + ']') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
  BEGIN
    IF EXISTS (SELECT 1 FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[' + @newName + ']') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    BEGIN
      EXEC (N'DROP PROCEDURE [dbo].[' + @newName + ']');
    END
    EXEC sp_rename @objname=@name, @newname=@newName
  END
END
go


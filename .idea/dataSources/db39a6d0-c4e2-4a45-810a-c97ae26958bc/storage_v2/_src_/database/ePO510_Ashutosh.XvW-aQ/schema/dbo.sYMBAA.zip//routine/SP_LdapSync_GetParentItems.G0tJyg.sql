CREATE PROCEDURE SP_LdapSync_GetParentItems
                              (
                                    @childId int = 0
                              )
                              AS BEGIN -- Define the CTE
                                   WITH cte AS (
                                        -- Initial select statement to kick off the recursion.
                                        SELECT ParentId
                                            FROM OrionLdapChildren WHERE ChildId = @childId
                                        UNION ALL
                                        -- Select statement used for each recursive interation.
                                        SELECT C.ParentId
                                            FROM OrionLdapChildren AS C
                                            INNER JOIN cte P ON C.ChildId = P.ParentId
                                        )
                                        SELECT * FROM OrionLdapItems WHERE Id IN
                                            (SELECT DISTINCT C.ParentId FROM cte as C)
                                        END
go


CREATE  VIEW OrionQueryGroupMemberships AS SELECT t.* FROM OrionQueryGroupMembershipsMT t
go


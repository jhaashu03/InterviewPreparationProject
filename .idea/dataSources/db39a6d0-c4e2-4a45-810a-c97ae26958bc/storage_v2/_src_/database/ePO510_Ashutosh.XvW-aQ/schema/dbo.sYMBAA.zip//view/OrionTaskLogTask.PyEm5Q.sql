CREATE VIEW [dbo].[OrionTaskLogTask] AS
    SELECT Id, Name, TaskSource, StartDate, EndDate, UserId, UserName, Status, TenantId,
           (CASE WHEN (OrionSchedulerTaskLog.Status != 10 AND OrionSchedulerTaskLog.EndDate IS NULL)
  	          THEN -1
  	          ELSE dbo.diffMillisecond(OrionSchedulerTaskLog.StartDate, ISNULL(OrionSchedulerTaskLog.EndDate, getUtcDate())) END) AS Duration
    FROM   dbo.OrionSchedulerTaskLog
    WHERE  (ParentId IS NULL)
go


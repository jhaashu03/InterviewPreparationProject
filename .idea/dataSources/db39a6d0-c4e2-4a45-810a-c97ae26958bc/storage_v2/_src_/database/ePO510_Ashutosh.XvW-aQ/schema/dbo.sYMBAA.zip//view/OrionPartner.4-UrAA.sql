-- second, create new version
CREATE VIEW OrionPartner AS
    SELECT * FROM OrionPartnerMT
    WHERE Uid =
    CASE
        WHEN 1 IN (SELECT TenantId FROM dbo.FN_Core_GetContextTenancyInfo()) THEN Uid
        ELSE (SELECT PartnerUID FROM OrionTenant   WHERE TenantId IN
                    (SELECT TenantId FROM dbo.FN_Core_GetContextTenancyInfo()))
    END
go


CREATE procedure [dbo].[SP_Task_LogMessage](
    @taskLogEntryId bigint,
    @messageType int,
    @message nvarchar(3000)
)
as
begin
    set NOCOUNT on;

    -- find the top-level task's ID for the argument task log entry ID (for SQUID integration)
    declare @topLevelTaskLogId bigint;
    select @topLevelTaskLogId = ParentId from OrionSchedulerTaskLog where Id = @taskLogEntryId;
    if @topLevelTaskLogId is null
    begin
       set @topLevelTaskLogId = @taskLogEntryId;
end

	insert into OrionSchedulerTaskLogDetail (TaskLogId, TopLevelTaskLogId, MessageDate, MessageType, Message )
	    values ( @taskLogEntryId, @topLevelTaskLogId, getUtcDate(), @messageType, @message );
end
go


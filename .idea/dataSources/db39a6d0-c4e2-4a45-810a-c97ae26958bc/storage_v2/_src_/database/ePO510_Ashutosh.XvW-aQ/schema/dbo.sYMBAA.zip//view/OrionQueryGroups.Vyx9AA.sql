CREATE  VIEW OrionQueryGroups AS SELECT t.* FROM OrionQueryGroupsMT t
go


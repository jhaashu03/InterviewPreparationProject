CREATE FUNCTION FN_Core_GetContextTenancyInfo ()
RETURNS @tid TABLE (TenantId int not null primary key clustered, IsSystemUser bit)
AS
BEGIN
  INSERT INTO @tid SELECT [dbo].[FN_Core_GetContextTenantId](), [dbo].[FN_Core_IsSystemUserInContext]()
  RETURN;
END
go


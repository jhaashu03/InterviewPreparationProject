CREATE PROCEDURE [dbo].[SP_Core_Upgrade_Recreate_FK]
	@TableNameRef	NVARCHAR(128)
AS
BEGIN
	DECLARE
		@StartTimeStamp	DATETIME
	,	@TimeStamp		VARCHAR(100);

	SELECT
		@StartTimeStamp	= GETUTCDATE()
	,	@TimeStamp		= CONVERT(VARCHAR(100), GETDATE());

	IF EXISTS	(SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'OrionFKRecreation') AND type in (N'U'))
	BEGIN

		-- get fk
		DECLARE
			@StartDateTime	DATETIME
		,	@EndDateTime	DATETIME
		,	@Name			NVARCHAR(512)
		,	@ParentTable	NVARCHAR(512)
		,	@ParentColumn	NVARCHAR(512)
		,	@PKTable		NVARCHAR(512)
		,	@PKColumn		NVARCHAR(512)
		,	@DeleteAction	TINYINT
		,	@DeleteType		NVARCHAR(60)
		,	@UpdateAction	TINYINT
		,	@UpdateType		NVARCHAR(60)
		,	@Query			NVARCHAR(MAX);

		SELECT
			Name
		,	ParentTable
		,	ParentColumn
		,	PKTable
		,	PKColumn
		,	DeleteAction
		,	UpdateAction
		,	CAST(0 AS BIT)	AS Processed
		INTO	#TempFKTables
		FROM	OrionFKRecreation
		WHERE
			PKTable	= @TableNameRef

		WHILE EXISTS (SELECT 1 FROM #TempFKTables WHERE Processed = 0)
		BEGIN

			SET	@StartDateTime	= GETUTCDATE();

			SELECT TOP 1
				@Name			= Name
			,	@ParentTable	= ParentTable
			,	@ParentColumn	= ParentColumn
			,	@PKTable		= PKTable
			,	@PKColumn		= PKColumn
			,	@DeleteAction	= DeleteAction
			,	@UpdateAction	= UpdateAction
			FROM	#TempFKTables
			WHERE
				Processed	= 0

			SET	@TimeStamp	= CONVERT(VARCHAR(100), GETDATE());
			RAISERROR('<<< CREATING FK %s TO %s : %s >>>', 0, 1, @Name, @ParentTable, @TimeStamp) WITH NOWAIT

            SELECT
            	@Query	= CASE
				WHEN @DeleteAction	= 1
					THEN ' ON DELETE CASCADE'
				WHEN @DeleteAction	= 2
					THEN ' ON DELETE SET NULL'
				WHEN @DeleteAction	= 3
					THEN ' ON DELETE SET DEFAULT'
				WHEN @DeleteAction	= 0
					THEN ' '
				ELSE	' '
			END

			SELECT
            	@Query	= @Query + CASE
				WHEN @UpdateAction	= 1
					THEN ' ON UPDATE CASCADE'
				WHEN @UpdateAction	= 2
					THEN ' ON UPDATE SET NULL'
				WHEN @UpdateAction	= 3
					THEN ' ON UPDATE SET DEFAULT'
				WHEN @UpdateAction	= 0
					THEN ' '
				ELSE	' '
			END

			SET @Query = 'ALTER TABLE ' + @ParentTable + ' WITH CHECK ADD CONSTRAINT ' + @Name + ' FOREIGN KEY
			(
				' + @ParentColumn +
			')
			REFERENCES ' + @PKTable +
			'(
				' + @PKColumn +
			')' + @Query

			EXEC	(@Query)

			UPDATE	#TempFKTables
			SET
				Processed	= 1
			WHERE
				Name		= @Name
			AND	ParentTable	= @ParentTable

			SET @EndDateTime	= GETUTCDATE();


			SET	@TimeStamp	= CONVERT(VARCHAR(100), GETDATE());
			RAISERROR('<<< ADDED FK %s TO %s : %s >>>', 0, 1, @Name, @ParentTable, @TimeStamp) WITH NOWAIT

		END


		DROP TABLE	#TempFKTables
	END
END
go


/****** Object:  StoredProcedure [dbo].[SP_Core_FetchExpiredAndAboutToExpirePasswordUsers]
This Stored Procedure does the following:
1) Fetch the Expiry interval from OrionUserAccountRule-PasswordExpiryRule Table
2) Based on the expiry interval, calculate the Days in Diff between the User's LastPasswordChangedDate column and current date
3) Id, Name and DaysDiff calculated in Step 2 is stored in Temp Table for usage
4) Based on the DaysDiff, ChangePassword Column in OrionUsersMT table is reset from 0 to 1 if DaysDiff is 0
5) Return Id, Name, DaysDiff and ChangePassword column back to Caller
*/
CREATE PROCEDURE [dbo].[SP_Core_FetchExpiredAndAboutToExpirePasswordUsers] (
  @Mode         TINYINT, -- 1 - Only Single User, 2 - Update for all Users
  @UserName     NVARCHAR(128) = '' -- UserName is required in @Mode=1, UserName is by default empty and not required in @Mode=2 which is for all users
)
AS
BEGIN
  DECLARE @PasswordExpiryInterval AS INT
  DECLARE @PasswordExpiryThresholdDays AS INT
  SELECT @PasswordExpiryInterval = CONVERT(INT,CONVERT(VARCHAR(5),[Setting]))
        FROM OrionUserAccountRule
        WHERE [Name]='PasswordExpiryRule'
  SELECT @PasswordExpiryThresholdDays = CONVERT(INT,CONVERT(VARCHAR(5),[Value]))
        FROM OrionServerPropertiesMT
        WHERE [Key]= 'user.password.expiry.threshold'
  IF(@Mode = 1)
  BEGIN
         /* Fetches the list of users whose password falls within the expiry window*/
       IF EXISTS(SELECT 1 FROM OrionUsersMT AS OU WHERE Name=@UserName AND @PasswordExpiryInterval - (DATEDIFF(DAY,OU.LastPasswordChangedDate,GETUTCDATE())) <= 0)
       BEGIN
             SELECT 1;
       END
       ELSE
       BEGIN
            SELECT 0;
       END
    END
  ELSE
  BEGIN
       /* Fetches the list of users whose password falls within the expiry window*/
         SELECT Id, Name,  @PasswordExpiryInterval - (DATEDIFF(DAY,OU.LastPasswordChangedDate,GETUTCDATE())) AS DaysDiff INTO #TempUserTable
         FROM OrionUsersMT AS OU
         WHERE @PasswordExpiryInterval - (DATEDIff(DAY,OU.LastPasswordChangedDate,GETUTCDATE())) <= @PasswordExpiryThresholdDays

         /* Update will update the ChangePassword flag once if the password has expired*/
         UPDATE OU SET OU.ChangePassword = 1 FROM OrionUsersMT AS OU
         JOIN #TempUserTable AS #tut
         ON #tut.Id = OU.Id AND #tut.DaysDiff <= 0
         AND OU.ChangePassword = 0

         /*Return the Result set */
         SELECT DISTINCT OU.Id, #tut.Name, OU.ChangePassword, #tut.DaysDiff
         From OrionUsersMT AS OU
         JOIN #TempUserTable AS #tut
         ON OU.Id = #tut.Id
         DROP TABLE #TempUserTable
  END
END
go


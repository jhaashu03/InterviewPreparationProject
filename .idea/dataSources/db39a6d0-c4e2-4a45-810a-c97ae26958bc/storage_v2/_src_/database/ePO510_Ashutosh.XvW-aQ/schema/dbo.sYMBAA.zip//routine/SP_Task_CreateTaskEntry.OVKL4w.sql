CREATE procedure [dbo].[SP_Task_CreateTaskEntry](
    @name nvarchar(128),
    @taskSource nvarchar(100),
    @userId int,
    @userName nvarchar(100),
    @status int,
    @tenantId int = null
)
as
begin
  set NOCOUNT on;

	IF @tenantId is null
    SET @tenantId = dbo.FN_Core_GetContextTenantId();

	insert into OrionSchedulerTaskLog (Name, TaskSource, StartDate, UserId, UserName, Status, ParentId, TenantId )
	    values ( @name, @taskSource, getUtcDate(), @userId, @userName, @status, null, @tenantId );
    return SCOPE_IDENTITY();
end
go


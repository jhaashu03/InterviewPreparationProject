CREATE  VIEW OrionTaskQueue AS SELECT t.* FROM OrionTaskQueueMT t
go


CREATE VIEW OrionReportImage AS
    SELECT * FROM OrionReportImageMT
    WHERE OrionReportImageMT.ReportId IN (SELECT Id FROM OrionReport)
go


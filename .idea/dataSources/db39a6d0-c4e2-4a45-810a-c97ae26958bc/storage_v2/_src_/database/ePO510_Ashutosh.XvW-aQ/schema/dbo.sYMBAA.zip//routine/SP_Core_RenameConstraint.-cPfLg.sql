CREATE PROCEDURE SP_Core_RenameConstraint
(
@tableName VARCHAR(255),
@columnName VARCHAR(255),
@newName VARCHAR(255),
@constraint VARCHAR(2)
)
AS
BEGIN
  DECLARE @constraintName VARCHAR(255) = NULL
  DECLARE @amount INTEGER = 0
  CREATE TABLE #TEMP
  (
  name NVARCHAR(255)
  )

  IF @constraint = 'D' OR @constraint = 'DF'
  BEGIN
    INSERT INTO #TEMP(name)
    SELECT df.name FROM sys.default_constraints df
    JOIN sys.tables tab ON tab.object_id = df.parent_object_id
    JOIN sys.columns c ON c.object_id = tab.object_id AND c.column_id = df.parent_column_id
    WHERE tab.name = @tableName AND c.name = @columnName
    GROUP BY df.name
  END
  IF @constraint = 'C' OR @constraint = 'CK'
  BEGIN
    INSERT INTO #TEMP(name)
    SELECT ch.name FROM sys.check_constraints ch
    JOIN sys.tables tab ON tab.object_id = ch.parent_object_id
    JOIN sys.columns c ON c.object_id = tab.object_id AND c.column_id = ch.parent_column_id
    WHERE tab.name = @tableName AND c.name = @columnName
    GROUP BY ch.name
  END
  IF @constraint = 'F' OR @constraint = 'FK'
  BEGIN
    INSERT INTO #TEMP(name)
    SELECT fks.name FROM sys.tables t
     JOIN sys.foreign_key_columns fk ON fk.parent_object_id = t.object_id
     JOIN sys.columns c ON c.object_id = t.object_id AND c.column_id = fk.parent_column_id
     JOIN sys.tables st ON fk.referenced_object_id = st.object_id
     JOIN sys.foreign_keys fks ON fk.parent_object_id = fks.parent_object_id AND fks.referenced_object_id = fk.referenced_object_id
     WHERE t.name = @tableName AND c.name = @columnName
     GROUP BY fks.name
  END
  IF @constraint = 'U'
  BEGIN
    SET @constraint = 'UQ'
  END
  IF @constraint = 'P'
  BEGIN
    SET @constraint = 'PK'
  END
  IF @constraint = 'UQ' OR @constraint = 'PK'
  BEGIN
  INSERT INTO #TEMP(name)
    SELECT k.name FROM sys.tables t
      JOIN sys.key_constraints k ON k.parent_object_id = t.object_id
      JOIN sys.index_columns i ON i.index_id = k.unique_index_id AND i.object_id = t.object_id
      JOIN sys.columns c ON c.object_id = t.object_id AND c.column_id = i.column_id
      WHERE t.name = @tableName AND c.name = @columnName AND k.type = @constraint
      GROUP BY k.name
  END

  SELECT @amount = COUNT(*) FROM #TEMP
  SELECT @constraintName = name FROM #TEMP

  DROP TABLE #TEMP

  IF @constraintName IS NOT NULL AND 1 = @amount
  BEGIN
	  EXEC sp_rename @constraintName, @newName, 'OBJECT';
	  PRINT 'RENAMING CONSTRAINT ' + @constraintName + ' FROM [dbo].[' + @tableName + ']:[' + @columnName + '] TO ' + @newName
  END
END
go


CREATE PROC dbo.OrionSchedulerTaskLogDataMigration
(
	@BatchCount int
)
AS
BEGIN
SET NOCOUNT ON;
SET XACT_ABORT ON;

	DECLARE @Start_Id bigint, @End_Id bigint, @RefId bigint, @InsertRow bigint, @DeleteRow bigint, @LogID int, @InsertDetailRow bigint, @DeleteDetailRow bigint, @DetailLogID int;

	IF OBJECT_ID('OrionSchedulerTaskLogMTDrop') IS NULL
		RETURN;

	SELECT @Start_Id = ISNULL(MIN(Id), 0), @RefId = ISNULL(MAX(Id), 0) FROM dbo.OrionSchedulerTaskLogMTDrop WITH (NOLOCK);
	SET @End_Id = CASE WHEN @Start_Id + @BatchCount < 0 THEN 0 ELSE @Start_Id + @BatchCount END;

	BEGIN TRY
		IF @RefId > 0
		BEGIN

			--Insert OrionSchedulerTaskLog
			INSERT dbo.EPOMigrationLog (Event,StartID,EndID,StartTime)
			VALUES('OrionSchedulerTaskLog', @Start_Id, @End_Id, GETUTCDATE());

			SET @LogID = SCOPE_IDENTITY();

			SET IDENTITY_INSERT dbo.OrionSchedulerTaskLog ON;

			INSERT dbo.OrionSchedulerTaskLog
			(
				Id,
				Name,
				TaskSource,
				StartDate,
				EndDate,
				UserId,
				UserName,
				Status,
				ParentId,
				TenantId,
				ClusterNodeId
			)

			SELECT
				Id,
				Name,
				TaskSource,
				StartDate,
				EndDate,
				UserId,
				UserName,
				Status,
				ParentId,
				TenantId,
				ClusterNodeId
			FROM dbo.OrionSchedulerTaskLogMTDrop WITH (NOLOCK)
			WHERE Id >= @Start_Id AND Id < @End_Id
			ORDER BY Id;

			SET @InsertRow = @@ROWCOUNT;

			SET IDENTITY_INSERT dbo.OrionSchedulerTaskLog OFF;

			--Insert OrionSchedulerTaskLogDetail
			IF OBJECT_ID('OrionSchedulerTaskLogDetailMTDrop') > 0
			BEGIN
				INSERT dbo.EPOMigrationLog (Event,StartID,EndID,StartTime)
				VALUES('OrionSchedulerTaskLogDetail', @Start_Id, @End_Id, GETUTCDATE());

				SET @DetailLogID = SCOPE_IDENTITY();

				SET IDENTITY_INSERT dbo.OrionSchedulerTaskLogDetail ON;

				ALTER TABLE	dbo.OrionSchedulerTaskLogDetail NOCHECK CONSTRAINT FK_OrionSchedulerTaskLogDetail_OrionSchedulerTaskLog;

				INSERT dbo.OrionSchedulerTaskLogDetail
				(
					Id,
					TaskLogId,
					TopLevelTaskLogId,
					MessageDate,
					MessageType,
					Message
				)

				SELECT
					A.Id,
					A.TaskLogId,
					A.TopLevelTaskLogId,
					A.MessageDate,
					A.MessageType,
					A.Message
				FROM dbo.OrionSchedulerTaskLogDetailMTDrop A WITH (NOLOCK) JOIN dbo.OrionSchedulerTaskLogMTDrop B WITH (NOLOCK)
				ON A.TopLevelTaskLogId = B.Id
				WHERE B.Id >= @Start_Id AND B.Id < @End_Id;

				SET @InsertDetailRow = @@ROWCOUNT;

				SET IDENTITY_INSERT dbo.OrionSchedulerTaskLogDetail OFF;

				ALTER TABLE	dbo.OrionSchedulerTaskLogDetail CHECK CONSTRAINT FK_OrionSchedulerTaskLogDetail_OrionSchedulerTaskLog;
			END

			--Delete OrionSchedulerTaskLogDetail
			IF @InsertDetailRow > 0
			BEGIN
				DELETE A
				FROM dbo.OrionSchedulerTaskLogDetailMTDrop A JOIN dbo.OrionSchedulerTaskLogMTDrop B WITH (NOLOCK)
				ON A.TopLevelTaskLogId = B.Id
				WHERE B.Id >= @Start_Id AND B.Id < @End_Id;

				SET @DeleteDetailRow = @@ROWCOUNT;
			END

			UPDATE dbo.EPOMigrationLog SET InsertRowCnt = @InsertDetailRow, DeleteRowCnt = @DeleteDetailRow, EndTime = GETUTCDATE(), Status = 'S'
			WHERE LogID = @DetailLogID;

			IF NOT EXISTS(SELECT TOP 1 1 FROM dbo.OrionSchedulerTaskLogDetailMTDrop)
				DROP TABLE dbo.OrionSchedulerTaskLogDetailMTDrop;

			--Delete OrionSchedulerTaskLog
			IF @InsertRow > 0
			BEGIN
				DELETE dbo.OrionSchedulerTaskLogMTDrop
				WHERE Id >= @Start_Id AND Id < @End_Id;

				SET @DeleteRow = @@ROWCOUNT;
			END

			UPDATE dbo.EPOMigrationLog SET InsertRowCnt = @InsertRow, DeleteRowCnt = @DeleteRow, EndTime = GETUTCDATE(), Status = 'S'
			WHERE LogID = @LogID;

			IF NOT EXISTS(SELECT TOP 1 1 FROM dbo.OrionSchedulerTaskLogMTDrop)
			BEGIN
				DROP TABLE dbo.OrionSchedulerTaskLogMTDrop;
				ALTER TABLE dbo.OrionTaskQueueMT CHECK CONSTRAINT FK_OrionTaskQueue_TaskLog;
			END

		END
		ELSE
		BEGIN
			IF NOT EXISTS(SELECT TOP 1 1 FROM dbo.OrionSchedulerTaskLogMTDrop)
			BEGIN
        DROP TABLE dbo.OrionSchedulerTaskLogMTDrop;
        ALTER TABLE dbo.OrionTaskQueueMT CHECK CONSTRAINT FK_OrionTaskQueue_TaskLog;
      END

			IF NOT EXISTS(SELECT TOP 1 1 FROM dbo.OrionSchedulerTaskLogDetailMTDrop)
				DROP TABLE dbo.OrionSchedulerTaskLogDetailMTDrop;
		END

	END TRY
	BEGIN CATCH
		DECLARE
			@ErrorMessage NVARCHAR(4000)
		,	@ErrorSeverity INT
		,	@ErrorState INT;

		SELECT
			@ErrorMessage = ERROR_MESSAGE(),
			@ErrorSeverity = ERROR_SEVERITY(),
			@ErrorState = ERROR_STATE();


		UPDATE dbo.EPOMigrationLog SET InsertRowCnt = @InsertRow, DeleteRowCnt = @DeleteRow, EndTime = GETUTCDATE(), Status = 'F', ErrorMsg = ERROR_MESSAGE()
		WHERE LogID = @LogID;

		-- Use RAISERROR inside the CATCH block to return error
		-- information about the original error that caused
		-- execution to jump to the CATCH block.
		RAISERROR (@ErrorMessage, -- Message text.
				   @ErrorSeverity, -- Severity.
				   @ErrorState -- State.
				   );
	END CATCH

END
go


create procedure [dbo].[SP_Core_Audit](
    @userId int,
    @userName nvarchar(256),
    @priority int,
    @cmdId nvarchar(256),
    @cmdName nvarchar(256),
    @message nvarchar(2048),
    @success bit,
    @startTime datetime,
    @endTime datetime,
    @tenantId int
)
as
begin
    set NOCOUNT on;
    IF @tenantId is null
        SET @tenantId = dbo.FN_Core_GetContextTenantId();
	insert into OrionAuditLog (UserId, UserName, Priority, CmdName, Message, Success, StartTime, EndTime, TenantId)
	    values ( @userId, @userName, @priority, @cmdName, @message, @success, @startTime, @endTime, @tenantId );
end
go


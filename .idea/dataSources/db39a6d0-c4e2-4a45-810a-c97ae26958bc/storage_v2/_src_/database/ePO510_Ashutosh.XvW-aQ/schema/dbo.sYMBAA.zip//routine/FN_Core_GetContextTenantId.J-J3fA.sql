CREATE FUNCTION FN_Core_GetContextTenantId()
RETURNS int
BEGIN
  RETURN dbo.FN_Core_GetContextTenantIdImpl()
END
go


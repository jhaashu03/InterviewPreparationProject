CREATE PROCEDURE SP_LdapSync_GetChildItems (
    @childId        INT = 0,
    @searchString   NVARCHAR (200) = NULL,
    @types          NVARCHAR(4000) = 'user,group',
    @recursive      BIT = 0
)
AS
BEGIN
    --------------------------------------------------------------------------------
    -- Author: Wayne Gibson
    -- Stored procedure to return the child items for an item, with optional
    -- search.
    --
    -- @param childId The Id of the parent to start the search from
    -- @param searchString Allows for search on the first part of the DN only.
    --                     This is optional.
    -- @param types List of the types of items to be returned.
    -- @param recursive 1 to go more than 1 level deep.
    --
    IF @searchString IS NULL
        BEGIN
            SET @searchString = '';
        END

    IF @types IS NULL
        BEGIN
            SET @types = 'user,group';
        END

    DECLARE @tableOfTypes TABLE (
        [value] nvarchar(100)
    )

    INSERT INTO @tableOfTypes
      SELECT [value] FROM dbo.OrionLdapSplit(',', @types);

   IF LEN(@searchString) = 0
     BEGIN
       SELECT *
         FROM OrionLdapItems
       WHERE Id IN (SELECT DISTINCT ID FROM OrionLdapGetChildItems(@childId, @recursive))
             AND ObjectCategory IN (SELECT [Value] FROM @tableOfTypes)
     END
   ELSE
     BEGIN
       SET @searchString = '__=%'+@searchString+'%';
       SELECT *
         FROM OrionLdapItems
       WHERE Id IN (SELECT DISTINCT ID FROM OrionLdapGetChildItems(@childId, @recursive))
             AND ObjectCategory IN (SELECT [Value] FROM @tableOfTypes)
             AND LEFT(dn, charindex(',', dn)) LIKE @searchString
     END
END
go



            CREATE FUNCTION [dbo].[OrionLdapGetChildItems] (
              @parentId INT = 0,
              @recursive BIT = 1
            )
            RETURNS @result table
            (
              [id] int
            )
            AS
            BEGIN
                IF @recursive = 1
                    BEGIN
                        WITH cte AS
                        (
                          -- Initial select statement to kick off the recursion.
                          SELECT ChildId
                            FROM OrionLdapChildren
                            WHERE ParentId = @parentId
                          UNION ALL
                          -- Select statement used for each recursive interation.
                          SELECT C.Childid
                            FROM    OrionLdapChildren AS C
                                  INNER JOIN
                                    cte P
                                  ON C.ParentId = P.ChildId
                        )
                        INSERT INTO @result
                        SELECT *
                          FROM cte AS C
                    END
                ELSE
                    INSERT INTO @result
                        SELECT ChildId
                          FROM OrionLdapChildren
                          WHERE ParentId = @parentId
              RETURN
            END

            go


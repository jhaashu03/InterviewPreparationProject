CREATE VIEW OrionUsers AS (SELECT * FROM OrionUsersMT)
go


CREATE  VIEW OrionDashboardPage AS SELECT t.* FROM OrionDashboardPageMT t
go


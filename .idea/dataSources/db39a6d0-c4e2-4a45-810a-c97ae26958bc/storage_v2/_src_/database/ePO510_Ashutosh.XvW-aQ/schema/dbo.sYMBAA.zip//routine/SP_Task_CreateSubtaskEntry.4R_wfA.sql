CREATE procedure [dbo].[SP_Task_CreateSubtaskEntry](
    @parentId bigint,
    @name nvarchar(128),
    @userId int,
    @userName nvarchar(100),
    @status int,
    @tenantId int = null
)
as
begin
    set NOCOUNT on;
    -- just look up the parent's TaskSource and use that for the child entry's task source
  declare @taskSource nvarchar(100);

	IF @tenantId is null
    SET @tenantId = dbo.FN_Core_GetContextTenantId();

  select @taskSource = TaskSource from OrionSchedulerTaskLog where Id = @parentId;
	insert into OrionSchedulerTaskLog (Name, TaskSource, StartDate, UserId, UserName, Status, ParentId, TenantId )
	    values ( @name, @taskSource, getUtcDate(), @userId, @userName, @status, @parentId, @tenantId );
    return SCOPE_IDENTITY();
end
go


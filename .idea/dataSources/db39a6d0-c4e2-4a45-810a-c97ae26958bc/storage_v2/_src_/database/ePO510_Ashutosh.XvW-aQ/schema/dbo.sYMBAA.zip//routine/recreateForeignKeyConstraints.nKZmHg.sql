CREATE PROCEDURE recreateForeignKeyConstraints
AS
BEGIN
	DECLARE
	@tableName VARCHAR(512),
	@constraintName VARCHAR(512),
	@columnName VARCHAR(512),
	@refColumnName VARCHAR(512),
	@columnType VARCHAR(512),
	@refColumnType VARCHAR(512),
	@fkParentTable VARCHAR(512),
	@deleteAction VARCHAR(512),
	@updateAction VARCHAR(512);

	SELECT TableName,ColumnName,ReferencedColumnName,CName,FKParentTable,Processed,OnlyFKDropped,DelAction,UpdAction
	  INTO #tempMetaTable
		FROM _bigint_migration_590
		WHERE Processed = 0;

	SET rowcount 1;

	SELECT TOP 1 @tableName = TableName,
				 @constraintName = CName,
				 @columnName = ColumnName,
				 @refColumnName = ReferencedColumnName,
				 @deleteAction = DelAction,
				 @updateAction = UpdAction,
				 @fkParentTable = FKParentTable FROM #tempMetaTable;

	WHILE EXISTS(SELECT 1 FROM #tempMetaTable WHERE Processed = 0)
	BEGIN
		IF (@updateAction = 'NO_ACTION')
		BEGIN
			SET @updateAction = 'NO ACTION';
		END

		SELECT @columnType = DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = @fkParentTable AND COLUMN_NAME = @refColumnName;
		SELECT @refColumnType = DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = @tableName AND COLUMN_NAME = @columnName;

		IF (@columnType = @refColumnType)
		BEGIN
			EXEC('ALTER TABLE '+@tableName+' WITH CHECK ADD  CONSTRAINT ['+@constraintName+'] FOREIGN KEY(['+@columnName+']) REFERENCES ['+@fkParentTable+'] (['+@refColumnName+']) ON DELETE '+@deleteAction+' ON UPDATE '+@updateAction);
			EXEC('ALTER TABLE '+@tableName+' CHECK CONSTRAINT ['+@constraintName+']');
		END

		UPDATE #tempMetaTable SET Processed = 1 where CName = @constraintName;

		SELECT TOP 1 @tableName = TableName,
				 @constraintName = CName,
				 @columnName = ColumnName,
				 @refColumnName = ReferencedColumnName,
				 @deleteAction = DelAction,
				 @updateAction = UpdAction,
				 @fkParentTable = FKParentTable FROM #tempMetaTable WHERE Processed = 0;
	END
END;
go


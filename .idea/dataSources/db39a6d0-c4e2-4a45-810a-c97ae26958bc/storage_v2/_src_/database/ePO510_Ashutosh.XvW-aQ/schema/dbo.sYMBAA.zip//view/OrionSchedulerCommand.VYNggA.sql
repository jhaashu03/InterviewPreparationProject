--
-- CREATE VIEW
--
CREATE VIEW OrionSchedulerCommand AS
  -- OrionSchedulerTask view already restricts table to the CONTEXT_INFO tenancy, we just have to join to it
  SELECT [dbo].[OrionSchedulerCommandMT].* FROM [dbo].[OrionSchedulerCommandMT]
  WHERE [dbo].[OrionSchedulerCommandMT].SchedulerTaskId IN (SELECT Id FROM [dbo].[OrionSchedulerTask])
go


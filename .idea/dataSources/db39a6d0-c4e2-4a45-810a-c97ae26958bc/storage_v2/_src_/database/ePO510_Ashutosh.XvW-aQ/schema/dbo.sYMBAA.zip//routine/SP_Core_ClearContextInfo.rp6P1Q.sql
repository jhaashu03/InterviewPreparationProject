CREATE PROCEDURE SP_Core_ClearContextInfo
AS
BEGIN
  DECLARE @ContextInfo varbinary(128) = (CAST(dbo.FN_Core_UNKNOWN_ID() as varbinary(8)) + CAST(dbo.FN_Core_UNKNOWN_ID() as varbinary(8)))
  SET CONTEXT_INFO @ContextInfo
END
go


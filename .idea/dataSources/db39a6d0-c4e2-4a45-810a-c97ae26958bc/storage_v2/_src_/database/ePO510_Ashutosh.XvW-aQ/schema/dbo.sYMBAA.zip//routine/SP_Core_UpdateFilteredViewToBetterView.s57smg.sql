CREATE PROCEDURE [dbo].[SP_Core_UpdateFilteredViewToBetterView]
	@ViewName nvarchar(256)
AS
/**
 * Version	: 5.7+
 *
 * This proc creates the new tenant-view pattern for mfs 5.7+ versions. If a view exists with the same name then
 * this proc alter the view or create the view. Reason for altering the view is to persist the roles of the existing
 * view.
 */
BEGIN
	DECLARE
		@Query		NVARCHAR(MAX)
	,	@RealName	NVARCHAR(256)

	RAISERROR('<<< Creating tenant-view for %s.', 0, 1, @ViewName) WITH NOWAIT

	SET @RealName = @ViewName + N'MT'

	-- If view exists alter the view to retain permissions
	IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'' + @ViewName + ''))
    BEGIN
		SET @Query = 'ALTER '
    END
    -- If view is not present then create new view
    ELSE
    BEGIN
    	SET @Query = 'CREATE '
    END

	SET @Query = @Query + ' VIEW ' + @ViewName + ' AS ' +
'
WITH Tenants AS
(
	SELECT	0 AS TenantId
	UNION
	SELECT dbo.FN_Core_GetContextTenantId()
	UNION
	SELECT TenantId
	FROM OrionTenant
	WHERE
		dbo.FN_Core_IsSystemUserInContext() = 1
)
    SELECT mtt.*
	FROM ' + @RealName + ' mtt
	JOIN Tenants t ON mtt.TenantId = t.TenantId'

	RAISERROR('<<< View script for %s: %s.', 0, 1, @ViewName, @Query) WITH NOWAIT

	EXEC sp_executesql @Query
END
go


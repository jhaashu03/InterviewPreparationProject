CREATE PROCEDURE [dbo].[MFSCore_RemoveTenantFilterInView]
	@ViewName nvarchar(256)
AS
BEGIN
	DECLARE
		@Query		NVARCHAR(MAX)
	,	@RealName	NVARCHAR(256)

	RAISERROR('<<< Removing tenant-filter for %s.', 0, 1, @ViewName) WITH NOWAIT
	SET @RealName = @ViewName + N'MT'
	-- If view exists alter the view to retain permissions
	IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'' + @ViewName + ''))
    BEGIN
		SET @Query = 'ALTER '
    END
    -- If view is not present then create new view
    ELSE
    BEGIN
    	SET @Query = 'CREATE '
    END
	SET @Query = @Query + ' VIEW ' + @ViewName + ' AS SELECT t.* FROM ' + @RealName + ' t '
	RAISERROR('<<< View script for %s: %s.', 0, 1, @ViewName, @Query) WITH NOWAIT
	EXEC sp_executesql @Query
END
go


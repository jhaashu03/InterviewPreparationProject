-- Create a reusable stored proc to [re]create views
CREATE PROCEDURE [dbo].[SP_Core_CreateContextView]
(
  @tableName VARCHAR(255),
  @viewName VARCHAR(255)
)
AS
BEGIN
	DECLARE @NewLineChar AS CHAR(2) = CHAR(13) + CHAR(10)
	DECLARE @Tab AS CHAR(1) = CHAR(9)
	DECLARE @SQL VARCHAR(2048)
	IF object_id ('dbo.' + @viewName, 'V') IS NOT NULL
	BEGIN
		SET @SQL = 'DROP VIEW ' + @viewName
		EXEC (@SQL)
	END

	SET @SQL =        'CREATE VIEW ' + @viewName + ' AS' + @NewLineChar
	SET @SQL = @SQL + @Tab + 'SELECT * FROM ' + @tableName + @NewLineChar
	SET @SQL = @SQL + @Tab + 'WHERE TenantId =' + @NewLineChar
	SET @SQL = @SQL + @Tab + 'CASE' + @NewLineChar
	SET @SQL = @SQL + @Tab + @Tab + 'WHEN dbo.FN_Core_IsSystemUserInContext() = 1 THEN TenantId' + @NewLineChar
	SET @SQL = @SQL + @Tab + @Tab + 'ELSE dbo.FN_Core_GetContextTenantId()' + @NewLineChar
	SET @SQL = @SQL + @Tab + 'END'
	EXEC (@SQL)
END
go


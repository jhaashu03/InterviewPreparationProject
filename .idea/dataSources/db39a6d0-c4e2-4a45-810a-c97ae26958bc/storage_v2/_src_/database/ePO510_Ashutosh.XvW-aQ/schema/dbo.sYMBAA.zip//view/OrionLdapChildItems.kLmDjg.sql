CREATE VIEW OrionLdapChildItems AS
    --------------------------------------------------------------------------------
    -- Author: John Burling
    -- View to obtain a list of OrionLdapChildItems

	SELECT ParentId, ChildId
        FROM [OrionLdapChildren]
        INNER JOIN [OrionLdapItems]
        ON [OrionLdapItems].Id = [OrionLdapChildren].ChildId
        WHERE [OrionLdapItems].LeafNode = 1
go


CREATE PROCEDURE dbo.OrionGetLdapServerByNetbios
(
    @netbios nvarchar(20)
)
AS
BEGIN
--------------------------------------------------------------------------------
-- Author: Niklas Hï¿½glund
-- Procedure to find the LDAP server ID (as in OrionLdapServers.Id) given a
-- netbios name.
--
-- If there are more than one entry in OrionLdapServers with the requested
-- netbios name, then one with preferred=1 in OrionLdapCache is preferred.
--
-- @netbios is the netbios name of the AD server
--------------------------------------------------------------------------------

SELECT TOP 1 S.Id
FROM OrionLdapServers S
LEFT JOIN OrionRegisteredServers RS ON S.RegisteredServerId = RS.Id
LEFT JOIN OrionLdapCache C ON RS.Name = C.RsName
WHERE S.NetBios = @netbios
ORDER BY C.Preferred DESC

END
go


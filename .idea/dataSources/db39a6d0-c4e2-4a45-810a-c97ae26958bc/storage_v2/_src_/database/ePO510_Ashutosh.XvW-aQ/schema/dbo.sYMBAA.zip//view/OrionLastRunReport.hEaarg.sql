-- Creating the more performant tenant filtered view for OrionLastRunReportMT.
CREATE  VIEW [dbo].[OrionLastRunReport] AS
WITH Tenants AS
(
	SELECT dbo.FN_Core_GetContextTenantId() AS TenantId
	UNION
	SELECT TenantId
	FROM OrionTenant
	WHERE
		dbo.FN_Core_IsSystemUserInContext() = 1
)
    SELECT mtt.*
	FROM OrionLastRunReportMT mtt WHERE UserId in (  SELECT Id FROM OrionUsers ou
	JOIN Tenants t ON ou.TenantId = t.TenantId )
go


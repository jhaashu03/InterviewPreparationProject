CREATE VIEW OrionLdapRequiredItemsComplete AS
    --------------------------------------------------------------------------------
    -- Author: Niklas Hoglund
    -- View to obtain a list of registered items.

	SELECT Extension, ServerId, RegisteredServerId, UniqueId, Dn, [Recursive], RefCount
        FROM [OrionLdapRequiredItems]
        INNER JOIN [OrionLdapItems] ON OrionLdapRequiredItems.ItemId = OrionLdapItems.Id
        LEFT JOIN [OrionLdapServers] ON OrionLdapItems.ServerId = OrionLdapServers.Id
go


CREATE PROCEDURE dbo.OrionGetMembersOfDn
(
	@serverID bigint,
    @dn nvarchar(2000),
	@category nvarchar(50),
	@recursive bit = 0
)
AS
BEGIN
--------------------------------------------------------------------------------
-- Author: Niklas Hï¿½glund
-- Procedure to return all DNs that are on a server below a given DN.
--
-- Only returns leaf DNs, i.e. the group DNs for intermediate groups are not
-- returned in the recursive case.
--
-- @serverID  Id of the server in the OrionLdapServers table.
--
-- @dn        The DN of an LDAP group.
--
-- @category  The category of item to get. This can be for example 'person' to
--            get users.
--
-- @recursive 0 to only retrieve users directly in the group specified by @dn,
--            1 to recursively look in subgroups as well.
--			  Defaults to 0 if not specified.
--------------------------------------------------------------------------------

	IF @recursive = 0 BEGIN
		-- Find the direct child items of a parent
		SELECT Child.Dn
		FROM OrionLdapItems Parent
		INNER JOIN OrionLdapChildItems CI ON Parent.Id = CI.ParentId
		INNER JOIN OrionLdapItems Child ON CI.ChildId = Child.Id
		 WHERE Parent.Dn = @dn
		   AND Parent.ServerId = @serverID
		   AND Child.ObjectCategory = @category
	END
	ELSE BEGIN
		-- Find child items below a particular group, recursively.
		--
		-- Note that the OrionLdapChildGroups table is kept flattened, so that
		-- if we have the groups a, b and c, where c is in b which is in a, then
		-- this is stored like this:
		--
		-- Parent Child
		-- ------ -----
		-- a      b
		-- a      c
		-- b      c
		--
		-- Thus, we don't need to do a loop here that recursively walks the group.

		DECLARE @groups table (
			Id bigint
		);

		-- Find the ID of the item with the given server and DN
		INSERT INTO @groups (id) (SELECT Id FROM OrionLdapItems WHERE ServerId=@serverId AND Dn=@dn)

		-- Add the IDs of all groups with this group as their parent
		INSERT INTO @groups (id) (SELECT CG.ChildId FROM @groups G INNER JOIN OrionLdapChildGroups CG ON G.Id = CG.ParentId);

		SELECT Child.Dn
		FROM @groups G
		INNER JOIN OrionLdapItems Parent ON G.Id = Parent.Id
		INNER JOIN OrionLdapChildItems CI ON Parent.Id = CI.ParentId
		INNER JOIN OrionLdapItems Child ON CI.ChildId = Child.Id
		WHERE Child.ObjectCategory = @category
	END
END
go


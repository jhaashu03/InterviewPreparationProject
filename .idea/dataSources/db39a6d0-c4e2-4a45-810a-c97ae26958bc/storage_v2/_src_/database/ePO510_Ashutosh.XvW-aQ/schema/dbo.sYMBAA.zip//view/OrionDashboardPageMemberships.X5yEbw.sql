CREATE  VIEW OrionDashboardPageMemberships AS SELECT t.* FROM OrionDashboardPageMembershipsMT t
go


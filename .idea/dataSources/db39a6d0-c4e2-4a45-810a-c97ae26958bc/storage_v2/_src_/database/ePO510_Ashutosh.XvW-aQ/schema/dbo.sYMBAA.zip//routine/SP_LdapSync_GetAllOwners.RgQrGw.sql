CREATE PROCEDURE [dbo].[SP_LdapSync_GetAllOwners]
(
	@ItemId bigint
)
AS
BEGIN
	----------------------------------------------------------------------------
	-- Return all the owners for a OrionLdapItem
	--------------------------------------------------------------------------------
	DECLARE @lookup1 TABLE (
		ParentId	bigint
	)
	INSERT INTO @lookup1(ParentId) VALUES(@ItemId)
	INSERT INTO @lookup1(ParentId)
		SELECT ParentId FROM OrionLdapChildItems WHERE ChildId = @ItemId

	DECLARE @lookup2 TABLE (
		ParentId	bigint
	)
	INSERT INTO @lookup2(ParentId)
		SELECT ParentId FROM OrionLdapChildGroups WHERE ChildId = @ItemId

	DECLARE @lookup3 TABLE (
		ParentId	bigint
	)
	INSERT INTO @lookup3(ParentId)
		SELECT ParentId FROM OrionLdapChildGroups WHERE ChildId IN (SELECT ParentId FROM OrionLdapChildren WHERE ChildId = @ItemId)

	SELECT * FROM OrionLdapRequiredItems
		WHERE
		    ItemID = @ItemId
			OR ItemId IN (SELECT ParentId FROM @lookup1)
			OR (Recursive = '1' AND ItemId IN (SELECT ParentId FROM @lookup2))
			OR (Recursive = '1' AND ItemId IN (SELECT ParentId FROM @lookup3))
END
go


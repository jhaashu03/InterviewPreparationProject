CREATE PROCEDURE dbo.SP_LdapSync_GetGroupDn
(
    @ServerId int,
    @Uuid nvarchar(64)
)
AS
BEGIN
--------------------------------------------------------------------------------
-- Procedure to return the Dn given the orionLdapServer Id and LdapUniqueId.
-- @orionLdapServerId
--------------------------------------------------------------------------------
  SELECT TOP 1 Dn FROM OrionLdapItems
      LEFT Join OrionLdapServers On OrionLdapItems.ServerId = OrionLdapServers.Id
      WHERE (OrionLdapServers.RegisteredServerId = @ServerId) AND (UniqueId = @Uuid);
END
go


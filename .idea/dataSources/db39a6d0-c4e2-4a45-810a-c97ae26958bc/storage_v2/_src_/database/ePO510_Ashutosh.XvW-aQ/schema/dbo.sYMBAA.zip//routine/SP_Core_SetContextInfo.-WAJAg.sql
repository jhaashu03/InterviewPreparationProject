CREATE PROCEDURE SP_Core_SetContextInfo
  @TenantId int,
  @UserId int = NULL
AS
BEGIN
  -- no-op
  RETURN
END
go


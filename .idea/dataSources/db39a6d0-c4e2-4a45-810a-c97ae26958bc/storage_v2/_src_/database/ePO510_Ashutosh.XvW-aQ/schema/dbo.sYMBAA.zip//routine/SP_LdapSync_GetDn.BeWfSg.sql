CREATE PROCEDURE dbo.SP_LdapSync_GetDn
(
    @NetBIOSName nvarchar(20),
    @UserName nvarchar(200)
)
AS
BEGIN
--------------------------------------------------------------------------------
-- Retrieve user ID, DN, and Guid given the NetBIOS name and user name
-- @NetBIOSName is the netbios name of the AD server
-- @UserName is the sam account name of the user
--------------------------------------------------------------------------------
	SELECT TOP 1 OrionLdapItems.Id, OrionLdapItems.Dn, OrionLdapItems.uniqueId
	FROM OrionLdapItems
        WHERE OrionLdapItems.InternalNetbiosServerId = @NetBIOSName AND
            OrionLdapItems.SamAccountName = @UserName
END
go


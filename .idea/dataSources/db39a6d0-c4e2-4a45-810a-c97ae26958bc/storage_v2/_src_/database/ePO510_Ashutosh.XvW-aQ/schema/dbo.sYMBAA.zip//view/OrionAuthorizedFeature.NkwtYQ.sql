CREATE  VIEW OrionAuthorizedFeature AS SELECT t.* FROM OrionAuthorizedFeatureMT t
go


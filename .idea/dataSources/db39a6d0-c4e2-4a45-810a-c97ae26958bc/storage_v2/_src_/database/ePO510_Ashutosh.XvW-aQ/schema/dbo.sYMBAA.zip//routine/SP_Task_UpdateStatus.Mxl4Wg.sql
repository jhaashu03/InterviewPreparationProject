CREATE procedure [dbo].[SP_Task_UpdateStatus](
    @taskLogEntryId bigint,
    @newStatus int
)
as
begin
    if( @newStatus in ( 0, 1, 2, 5 ) )
        begin
            -- status is finished, so set the end date
            update OrionSchedulerTaskLog set Status=@newStatus, EndDate=getUtcDate() where ID=@taskLogEntryId
        end
    else
        begin
            -- statis is not finished
             update OrionSchedulerTaskLog set Status=@newStatus where ID=@taskLogEntryId
        end
end
go


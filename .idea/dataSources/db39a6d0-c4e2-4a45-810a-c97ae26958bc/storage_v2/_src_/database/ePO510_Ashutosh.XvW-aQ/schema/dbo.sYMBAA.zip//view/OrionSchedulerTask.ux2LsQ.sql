CREATE  VIEW OrionSchedulerTask AS SELECT t.* FROM OrionSchedulerTaskMT t
go


CREATE PROCEDURE [dbo].[SP_Core_IsMultiTenantMode]
AS
BEGIN
	IF EXISTS (SELECT 1 FROM OrionServerPropertiesMT
	           WHERE [Key] = 'multi.tenant.mode' AND [TenantId] = 1
	           AND CAST(SUBSTRING([value], 1, 1) AS INT) = 1)
		RETURN 1
	RETURN 0
END
go


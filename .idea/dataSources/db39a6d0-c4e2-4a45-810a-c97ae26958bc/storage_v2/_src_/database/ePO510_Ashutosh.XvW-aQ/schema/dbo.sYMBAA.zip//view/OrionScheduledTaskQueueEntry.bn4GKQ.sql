--
-- CREATE VIEW
--
CREATE VIEW OrionScheduledTaskQueueEntry AS
  -- OrionSchedulerTask view already restricts table to the CONTEXT_INFO tenancy, we just have to join to it
  SELECT [dbo].[OrionScheduledTaskQueueEntryMT].* FROM [dbo].[OrionScheduledTaskQueueEntryMT]
  WHERE [dbo].[OrionScheduledTaskQueueEntryMT].SchedulerTaskID  IN (SELECT Id FROM [dbo].[OrionSchedulerTask])
go


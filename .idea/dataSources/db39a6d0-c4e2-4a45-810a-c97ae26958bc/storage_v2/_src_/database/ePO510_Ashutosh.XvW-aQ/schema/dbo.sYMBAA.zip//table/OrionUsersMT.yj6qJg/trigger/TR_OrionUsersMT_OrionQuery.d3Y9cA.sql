CREATE TRIGGER TR_OrionUsersMT_OrionQuery ON OrionUsersMT INSTEAD OF DELETE
   AS
    BEGIN
    SET NOCOUNT ON;
    DELETE FROM OrionQueryMT where UserId in ( select Id from DELETED)
    DELETE FROM OrionUsersMT where Id in ( select Id from DELETED)
    END
go


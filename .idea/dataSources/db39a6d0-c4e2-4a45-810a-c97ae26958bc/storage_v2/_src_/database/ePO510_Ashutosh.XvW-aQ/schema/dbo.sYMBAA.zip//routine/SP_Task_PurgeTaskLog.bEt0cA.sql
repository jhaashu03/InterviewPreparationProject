CREATE PROCEDURE [dbo].[SP_Task_PurgeTaskLog]
(
    @TenantId int = NULL
)
AS
BEGIN
SET NOCOUNT ON;
BEGIN TRANSACTION;

    DECLARE @numDeleted int;
    DECLARE @deleteResult int; -- holds result for a single deletion
	DECLARE @ParentId bigint;
	DECLARE @cur cursor;

	SET @numDeleted = 0;

	IF @TenantId IS NULL
    SET @TenantId = dbo.FN_Core_GetContextTenantId();

	-- find all deletable "parent" task log entries. Statuses : 0=successful 1=failed 2=terminated 5=stopped

	CREATE TABLE #TempParentTaskLogID
	(
		Id bigint,
		TenantId int
	)

	IF( @TenantId > 1 )
		INSERT INTO  #TempParentTaskLogID
		SELECT Id,TenantId
	    FROM dbo.OrionSchedulerTaskLog ostl
		WHERE ParentId IS NULL AND TenantId = @TenantId AND Status IN ( 0, 1, 2, 5 ) AND NOT EXISTS (SELECT TaskLogID FROM dbo.OrionTaskQueue otq WHERE otq.TaskLogID = ostl.Id);
	ELSE
		INSERT into #TempParentTaskLogID
		SELECT Id,TenantId
	    FROM dbo.OrionSchedulerTaskLog ostl
		WHERE ParentId IS NULL AND Status IN ( 0, 1, 2, 5 ) AND NOT EXISTS (SELECT TaskLogID FROM dbo.OrionTaskQueue otq WHERE otq.TaskLogID = ostl.Id);

	-- Logic of SP_Task_DeleteTaskLogEntryIfChildTasksDeletable
	WITH CTE
	AS
	(
		select ost.ParentId as Id ,ost.TenantId as  TenantId
		from OrionSchedulerTaskLog  ost INNER JOIN #TempParentTaskLogID temp
		ON ost.ParentId = temp.Id AND ost.Status in ( 4, 10 )
		GROUP BY ost.ParentId,ost.TenantId
		HAVING count(ost.Id) > 0
	)

	DELETE A
	FROM #TempParentTaskLogID A JOIN CTE B
	ON A.Id = B.Id AND A.TenantId = B.TenantId;

	CREATE TABLE #TempDeleteIds
	(
		Id bigint,
		TenantId int
	)

	INSERT INTO  #TempDeleteIds
	SELECT Id,TenantId from #TempParentTaskLogID

	CREATE TABLE #TempIds
	(
		Id bigint,
		TenantId int
	)

	DECLARE @Count int = 1;
    -- Recursively find and delete child tasklog entries
		WHILE (@Count > 0)
		BEGIN
			INSERT into #TempIds
			SELECT o.Id, t.TenantId
			FROM OrionSchedulerTaskLog o JOIN #TempParentTaskLogID t
			ON o.ParentId = t.Id ;

			SET @Count = @@ROWCOUNT;

			INSERT INTO #TempDeleteIds
			SELECT Id,TenantId FROM #TempIds;

			DELETE FROM #TempParentTaskLogID;

			INSERT INTO #TempParentTaskLogID
			SELECT Id,TenantId FROM #TempIds;

			DELETE FROM #TempIds;

		END

	DELETE A
	FROM OrionSchedulerTaskLog A JOIN #TempDeleteIds B
	ON A.Id = B.Id;
	SET @numDeleted = @@ROWCOUNT;

	DROP TABLE #TempParentTaskLogID,#TempDeleteIds,#TempIds ;

	COMMIT TRANSACTION;
	RETURN @numDeleted;
END
go

